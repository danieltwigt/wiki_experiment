Starting ICARUS
===============

.. autosummary::
   :toctree: generated

Steps at start of training:

Questions at the top
•	Automated Phone pupular distance scan
•	Is person familiar with VR? How many hours?
•	Is person familiar with Index Controller? How many hours?
•	Age?


Valve Index hardware introduction
•	Show grabbing out of VR (and explain this will show the controller in VR) and show Joystick (and request to be cautious as it will move them)

HMD Setup:
•	Perform Valve HMD setup https://steamcdn-a.akamaihd.net/steam/apps/1059530/manuals/KitQSG_EN.pdf

Checks in VR:
•	Check surroundings, ask user to describe them
•	Check readability of logo’s and adjust for incorrect vision

Instructions:
•	Please act as if you are in a real situation, we can monkey around later
•	Listen for my instructions before going
•	Think out loud

Tutorial:
•	Learn Clenching
o	Locate all buttons on request
•	Learn Locomotion (only teleport) - FT_ E21U1: Locomotion
•	Learn Grabbing - FT_ E21U2: Interaction
•	(Learn Scrolling)
•	Learn A for Analyse / Menu
•	Learn Pointing
•	Learn Trigger and Back

Reset the cleanroom - FT_ E11U1: Start, save, and resume a training scenario
