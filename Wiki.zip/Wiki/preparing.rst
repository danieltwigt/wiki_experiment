Preparing ICARUS
================

.. _ValveIndex: https://steamcdn-a.akamaihd.net/steam/apps/1059530/manuals/KitQSG_EN.pdf
.. autosummary::
   :toctree: generated

To start ICARUS, follow these steps:

Step 1: system requirements
---------------------------

If not done yet, ensure that the system requirements as described in <link> are met.

Step 2: dependancies
--------------------

If not done yet, ensure that dependancies as described in <link> are installed.

Step 3: Valve Index setup
-------------------------

If not done yet, ensure that the Valve Index is setup following instructions as provided in`ValveIndex`_, also accessible below.

.. raw:: html

  <embed src="https://steamcdn-a.akamaihd.net/steam/apps/1059530/manuals/KitQSG_EN.pdf" width="500" height="800" type="application/pdf">

Step 4: Unpacking ICARUS
------------------------

If not done yet, unpack ICARUS as included in the zip-file ICARUS_<build_number>.zip to a location of choice on the PC.

Step 5: Starting ICARUS
-----------------------

Start ICARUS by running the executable <installation location>\WindowsNoEditor\HADES.exe.
