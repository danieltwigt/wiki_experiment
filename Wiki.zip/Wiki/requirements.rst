System Requirements
===================

.. _SteamVR: https://store.steampowered.com/app/250820/SteamVR
.. _ValveIndex: https://store.steampowered.com/valveindex
.. autosummary::
   :toctree: generated

ICARUS runs as stand-alone, single user tool, applying a tethered VR headset. The hardware setup is as follows:

.. image:: images/ICARUS_HW_setup.jpg
  :width: 600
  :alt: Alternative text

ICARUS is developed and tested for the Valve Index HMD and Motion Controllers. For more information on the Valve Index, see `ValveIndex`_.

Minimum system requirements to run ICARUS are:

+---------------+------------------------------------------------+
| Component     | Requirement                                    |
+===============+================================================+
| Processor     | Dual Core with hyperthreading, or better       |
+---------------+------------------------------------------------+
| RAM           | 8 GB, or more                                  |
+---------------+------------------------------------------------+
| Video card    | NVIDIA GeForce GTX 970 ,AMD RX480, or better   |
+---------------+------------------------------------------------+

Software dependencies are:

+---------------+------------------------------------------------+
| Name          | Link                                           |
+===============+================================================+
| SteamVR       | `SteamVR`_                                     |
+---------------+------------------------------------------------+
